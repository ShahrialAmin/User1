export * from './TermsPage';
export * from './PrivacyPage';
export * from './RefundPolicyPage';
export * from './CookiePolicyPage';
export * from './ShipmentPolicyPage';